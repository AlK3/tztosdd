import React from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from 'react-router-dom';
import { Main } from './components/main/Main';
import { Private } from './components/private/Private';
import { ComplaintsPage } from './pages/ComplaintsPage';
import { DriverDocumentsPage } from './pages/DriverDocumentsPage';
import { RequestsPage } from './pages/RequestsPage';
import { SettingsPage } from './pages/SettingsPage';
import { UserProfilePage } from './pages/UserProfilePage';
import { UsersListPage } from './pages/UsersListPage';

export const App = () => {
  return (
    <Router>
      <header style={{ backgroundColor: "#aaffaa", gridArea: "header", height: "40px" }}>HEADER</header>
      <Main>
        <Routes>
          <Route index element={<>INDEX</>} />
          <Route element={<Private isAllowed={true} />}>
            <Route path="users" element={<UsersListPage />} />
            <Route path="requests">
              <Route path=":requestId" element={<>RequestDetailsPage.js</>} />
              <Route index element={<RequestsPage />} />
            </Route>
            <Route path="profiles/:userId" element={<UserProfilePage />} />
            <Route path="documents" element={<DriverDocumentsPage />} />
            <Route path="complaints" element={<ComplaintsPage />} />
            <Route path="settings" element={<SettingsPage />} />
          </Route>
          <Route path='*' element={<>NotFound</>} />
        </Routes>
      </Main>
    </Router>
  );
}