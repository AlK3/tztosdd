import React from 'react';
import { useLocation } from 'react-router-dom';
import { Transtion } from '../components/transition/Transition';
import { useParams } from 'react-router-dom';

export const UserProfilePage = () => {
  const { userId } = useParams();
  return (
    <Transtion>
      <div style={{ margin: "8px" }}><a href="#">breadcrumbs</a> / ... / <a href={useLocation().pathname}>location</a></div>
      <h1>{userId}</h1>
    </Transtion>
  );
}