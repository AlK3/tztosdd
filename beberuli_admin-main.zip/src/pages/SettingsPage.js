import React from 'react';
import { useLocation } from 'react-router-dom';
import { Transtion } from '../components/transition/Transition';

export const SettingsPage = () => {
  return (
    <Transtion>
      <div style={{ margin: "8px" }}><a href="#">breadcrumbs</a> / ... / <a href={useLocation().pathname}>location</a></div>
      <h1>SettingsPage.js</h1>
    </Transtion>
  );
}