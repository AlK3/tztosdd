import React from 'react';
import * as Yup from 'yup';
import { useLocation } from 'react-router-dom';
import { Formik, Form, Field } from 'formik';
import { Transtion } from '../components/transition/Transition';
import { List } from '../components/list/List';

const ValidationSchema = Yup.object().shape({
  firstName: Yup.string()
    .min(2, 'Too Short!')
    .max(50, 'Too Long!')
    .required('Required'),
  lastName: Yup.string()
    .min(2, 'Too Short!')
    .max(50, 'Too Long!')
    .required('Required'),
  email: Yup.string().email('Invalid email').required('Required'),
});

export const UsersListPage = () => {
  return (
    <Transtion>
      <div style={{ margin: "8px" }}><a href="#">breadcrumbs</a> / ... / <a href={useLocation().pathname}>location</a></div>

      <h1>Список Пользователей</h1>
      <p style={{ border: "2px solid #000000", maxWidth: "800px", backgroundColor: "#aaaaff" }}>
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
      </p>
      <br />
      <Formik
       initialValues={{
         firstName: '',
         lastName: '',
         email: '',
       }}
       validationSchema={ValidationSchema}
       onSubmit={values => {
         console.log(values);
       }}
     >
       {({ errors, touched }) => (
         <Form style={{ border: "2px solid #000000", maxWidth: "800px", backgroundColor: "#aaaaff" }}>
           <Field name="firstName" />
           {errors.firstName && touched.firstName ? (
             <div>{errors.firstName}</div>
           ) : null}
           <Field name="lastName" />
           {errors.lastName && touched.lastName ? (
             <div>{errors.lastName}</div>
           ) : null}
           <Field name="email" type="email" />
           {errors.email && touched.email ? <div>{errors.email}</div> : null}
           <button type="submit">Submit</button>
         </Form>
       )}
     </Formik>

      <List data={{ items: [
        { id: '1', avatar: 'localhost:3000/avatar.png', name: 'Albert', phone: '88005353535', date: new Date().toISOString(), rating: 5 },
        { id: '2', avatar: 'localhost:3000/avatar.png', name: 'Albert', phone: '88005353535', date: new Date().toISOString(), rating: 5 }
        ], type: 'user' }} />
      
    </Transtion>
  );
}