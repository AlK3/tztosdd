import React from 'react';
import * as Yup from 'yup';
import { useLocation } from 'react-router-dom';
import { Formik, Form, Field } from 'formik';
import { Transtion } from '../components/transition/Transition';
import { List } from '../components/list/List';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { loadDriverDocumentsListData } from '../store/actions/driverDocuments';

const ValidationSchema = Yup.object().shape({
  firstName: Yup.string()
    .min(2, 'Too Short!')
    .max(50, 'Too Long!')
    .required('Required'),
  lastName: Yup.string()
    .min(2, 'Too Short!')
    .max(50, 'Too Long!')
    .required('Required'),
  email: Yup.string().email('Invalid email').required('Required'),
});

export const DriverDocumentsPage = () => {
  const dispatch = useDispatch();
  const driverDocumentsListData = useSelector((state) => state.driverDocuments.driverDocumentsListData);

  useEffect(() => {
    dispatch(loadDriverDocumentsListData());
  }, []);

  return (
    <Transtion>
      <div style={{ margin: "8px" }}><a href="#">breadcrumbs</a> / ... / <a href={useLocation().pathname}>location</a></div>
      <h1>Документы Водителей</h1>
      <Formik
       initialValues={{
         firstName: '',
         lastName: '',
         email: '',
       }}
       validationSchema={ValidationSchema}
       onSubmit={values => {
         console.log(values);
       }}
     >
       {({ errors, touched }) => (
         <Form style={{ border: "2px solid #000000", maxWidth: "800px", backgroundColor: "#aaaaff" }}>
           <Field name="firstName" />
           {errors.firstName && touched.firstName ? (
             <div>{errors.firstName}</div>
           ) : null}
           <Field name="lastName" />
           {errors.lastName && touched.lastName ? (
             <div>{errors.lastName}</div>
           ) : null}
           <Field name="email" type="email" />
           {errors.email && touched.email ? <div>{errors.email}</div> : null}
           <button type="submit">Submit</button>
         </Form>
       )}
     </Formik>

      <List data={driverDocumentsListData} />
      
    </Transtion>
  );
}