import createSagaMiddleware from '@redux-saga/core';
import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { driverDocumentsReducer } from './reducers/driverDocuments';
import { rootSaga } from './sagas/rootSaga';

const rootReducer = combineReducers({
  driverDocuments: driverDocumentsReducer,
});

const sagaMiddleware = createSagaMiddleware();
export const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(sagaMiddleware),
});
sagaMiddleware.run(rootSaga);