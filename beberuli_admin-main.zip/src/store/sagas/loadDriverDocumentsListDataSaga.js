import { takeEvery, call, put } from '@redux-saga/core/effects';
import { loadDriverDocumentsListData } from '../reducers/driverDocuments';

function fetchDriverDocumentsData() {
  return fetch("/document_car")
    .then(response => response.json());
}

function* workerLoadDriverDocumentsData() {
  //const driverDocumentsData = yield call(fetchDriverDocumentsData);
  //yield put(loadDriverDocumentsListData(driverDocumentsData));
  yield put(loadDriverDocumentsListData({ items: [
    { id: '1', avatar: 'localhost:3000/avatar.png', name: 'Albert', phone: '88005353535', documents: [], rating: 5 },
    { id: '2', avatar: 'localhost:3000/avatar.png', name: 'Albert', phone: '88005353535', documents: [], rating: 5 }
    ], type: 'documents' }));
}

export function* watchLoadDriverDocumentsData() {
  yield takeEvery("LOAD_DRIVER_DOCUMENTS_DATA", workerLoadDriverDocumentsData);
}