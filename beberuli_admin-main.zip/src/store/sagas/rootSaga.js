import { all } from '@redux-saga/core/effects';
import { watchLoadDriverDocumentsData } from './loadDriverDocumentsListDataSaga';

export function* rootSaga() {
  yield all([
    watchLoadDriverDocumentsData(),
  ]);
}