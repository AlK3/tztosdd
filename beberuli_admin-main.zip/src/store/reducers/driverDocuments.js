import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  driverDocumentsListData: null,
}

const driverDocumentsSlice = createSlice({
  name: 'driverDocuments',
  initialState: initialState,
  reducers: {
    loadDriverDocumentsListData(state, action) {
      state.driverDocumentsListData = action.payload;
    },
  },
});

export const { loadDriverDocumentsListData } = driverDocumentsSlice.actions;
export const driverDocumentsReducer = driverDocumentsSlice.reducer;