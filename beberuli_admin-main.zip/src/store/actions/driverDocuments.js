export const loadDriverDocumentsListData = () => {
  return {
    type: "LOAD_DRIVER_DOCUMENTS_DATA",
  };
}