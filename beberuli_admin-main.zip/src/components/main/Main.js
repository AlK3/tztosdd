import React from 'react';
import { Nav } from '../nav/Nav';
import { StyledMain } from './Main.styles';

const listItems= [
  {
    id: "users",
    text: "Список Пользователей"
  },
  {
    id: "requests",
    text: "Заявки"
  },
  {
    id: "documents",
    text: "Документы Водителей"
  },
  {
    id: "complaints",
    text: "Жалобы"
  },
  {
    id: "settings",
    text: "Настройки"
  }
];

export const Main = ({ children }) => {
  return (
    <StyledMain>
      <Nav listItems={listItems}></Nav>
      {children}
    </StyledMain>
  );
}