import styled from 'styled-components';

export const StyledMain = styled.main`
  background-color: #ffaaaa;
  min-height: calc(100vh - 40px);
  max-width: 2560px;
  margin: 0 auto;
  display: flex;
`;