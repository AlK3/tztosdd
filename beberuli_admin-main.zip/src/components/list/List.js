import React from 'react';
import { Item } from '../item/Item';

export const List = ({ data }) => (
	<>
	  {data?.items ?
			data.items.map(item => ( <Item item={item} type={data.type} /> ))
			:
			<>
				{/*Skeleton*/}
				dddddd
			</>
	  }
	</>
);