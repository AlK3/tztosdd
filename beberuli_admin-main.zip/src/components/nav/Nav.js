import React from 'react';
import { Link } from 'react-router-dom';
import { StyledNav } from './Nav.styles';

export const Nav = ({ listItems }) => {
  return (
    <StyledNav>
      <ul>
        {listItems.map(item => (
          <li style={{ listStyleType: "none" }}><Link to={item.id} key={item.id}>{item.text}</Link></li>
        ))}
      </ul>
    </StyledNav>
  );
}