import styled from 'styled-components';

export const StyledNav = styled.nav`
  background-color: #ffaaff;
  grid-area: nav;
  flex-shrink: 0;
  @media (max-width: 768px) {
    display: none;
  }
`;