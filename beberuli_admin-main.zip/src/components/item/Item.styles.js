import styled from 'styled-components';

export const StyledItem = styled.div`
  display: flex;
  margin: 16px;
  border: 2px solid #ffffaa;
  border-radius: 10px;
  color: black;
  :link, :visited, :focus {
    background: #aaaaaa;
  }
  :hover {
    background: #aaaaaa;
    color: white;
  }
  
  :active {
    background: #aaaaaa;
    color: white;
  }
`;