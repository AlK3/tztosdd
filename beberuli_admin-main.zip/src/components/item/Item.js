import React from 'react';
import { Link } from 'react-router-dom';
import { StyledItem } from './Item.styles';

export const Item = ({ item, type }) => (
  <StyledItem>
    {(() => {
      switch(type) {
        case 'user':
          return (
            <>
              <Link to={`/profiles/${item.id}`}>{item.avatar}</Link>
              <Link to={`/profiles/${item.id}`}>{item.name}</Link>
              {item.phone}
              {item.date}
              {item.rating}
            </>
          );
        case 'documents':
          return (
            <>
              <Link to={`/profiles/${item.id}`}>{item.avatar}</Link>
              <Link to={`/profiles/${item.id}`}>{item.name}</Link>
              {item.phone}
              {item.documents}
              <button>Принять</button>
            </>
          );
        default:
          return null;
      }
    })()}
  </StyledItem>
);